# دليل البدء السريع - Flutter App

## المتطلبات الأساسية

قبل البدء، تأكد من تثبيت:
- Flutter SDK (3.0.0+)
- Android Studio أو VS Code
- Git

## خطوات التشغيل السريع

### 1. تحقق من تثبيت Flutter
```bash
flutter doctor
```
يجب أن ترى علامات ✓ خضراء أو على الأقل لا توجد أخطاء حرجة.

### 2. استنساخ المشروع
```bash
git clone <repository-url>
cd inventory-pwa/flutter_app
```

### 3. تثبيت التبعيات
```bash
flutter pub get
```

### 4. تشغيل التطبيق
```bash
flutter run
```

## الأوامر المفيدة

### تشغيل في وضع Debug
```bash
flutter run --debug
```

### تشغيل في وضع Release (أسرع)
```bash
flutter run --release
```

### بناء APK
```bash
flutter build apk --release
```
الملف سيكون في: `build/app/outputs/flutter-apk/app-release.apk`

### تنظيف المشروع
```bash
flutter clean
flutter pub get
```

### فحص المشاكل
```bash
flutter analyze
```

## اختيار الجهاز

### عرض الأجهزة المتاحة
```bash
flutter devices
```

### تشغيل على جهاز محدد
```bash
flutter run -d <device-id>
```

## حل المشاكل الشائعة

### المشكلة: "Flutter SDK not found"
**الحل**: تأكد من إضافة Flutter إلى PATH
```bash
export PATH="$PATH:`pwd`/flutter/bin"
```

### المشكلة: "Gradle build failed"
**الحل**: 
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
```

### المشكلة: "No connected devices"
**الحل**: 
- تأكد من تشغيل المحاكي
- أو توصيل جهاز فعلي مع تفعيل USB debugging

### المشكلة: "Package dependencies error"
**الحل**:
```bash
flutter pub cache repair
flutter pub get
```

## البدء بالتطوير

### بنية المشروع
```
lib/
├── main.dart              ← نقطة البداية
├── models/                ← نماذج البيانات
├── screens/               ← شاشات التطبيق
├── providers/             ← إدارة الحالة
├── services/              ← الخدمات
└── widgets/               ← المكونات القابلة لإعادة الاستخدام
```

### إضافة شاشة جديدة
1. أنشئ ملف في `lib/screens/`
2. استخدم Provider للوصول للبيانات
3. أضف التنقل من الشاشة الرئيسية

### إضافة نموذج بيانات جديد
1. أنشئ ملف في `lib/models/`
2. أضف `fromJson` و `toJson`
3. حدّث `StorageService` إذا لزم الأمر

## Hot Reload & Hot Restart

### Hot Reload (إعادة تحميل سريعة)
- اضغط `r` في Terminal
- أو احفظ الملف في VS Code
- يحافظ على الحالة الحالية

### Hot Restart (إعادة تشغيل كاملة)
- اضغط `R` في Terminal
- يعيد تشغيل التطبيق من البداية
- يمسح الحالة الحالية

## نصائح للتطوير

### 1. استخدم Flutter DevTools
```bash
flutter pub global activate devtools
flutter pub global run devtools
```

### 2. تفعيل Null Safety
الكود يستخدم Null Safety بالفعل

### 3. استخدم const عندما يكون ممكناً
```dart
const Text('مرحباً')  // أفضل
Text('مرحباً')        // يعمل لكن أبطأ
```

### 4. تجنب print() في Production
استخدم `debugPrint()` بدلاً منه

## الاختبار

### اختبار سريع للوظائف
1. شغل التطبيق
2. جرب إضافة صنف جديد
3. أضف دفعة بتاريخ صلاحية
4. أنشئ طلب جديد
5. تحقق من حفظ البيانات بإغلاق وإعادة فتح التطبيق

## الموارد المفيدة

### التوثيق الرسمي
- Flutter: https://flutter.dev/docs
- Dart: https://dart.dev/guides
- Provider: https://pub.dev/packages/provider

### الدروس التعليمية
- Flutter Codelabs: https://flutter.dev/codelabs
- Flutter Cookbook: https://flutter.dev/cookbook

## الدعم

في حال واجهت أي مشكلة:
1. تحقق من `flutter doctor`
2. راجع ملف DOCUMENTATION.md
3. ابحث في GitHub Issues
4. تواصل مع المطور: 0550360705

---

**نصيحة**: ابدأ بقراءة README.md و DOCUMENTATION.md للحصول على فهم شامل للمشروع.

حظاً موفقاً! 🚀
